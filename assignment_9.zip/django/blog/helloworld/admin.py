from django.contrib import admin
from helloworld.models import Post

# Register your models here.
admin.site.register(Post)